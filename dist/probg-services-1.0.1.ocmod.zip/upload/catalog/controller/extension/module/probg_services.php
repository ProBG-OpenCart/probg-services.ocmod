<?php
class ControllerExtensionModuleProbgServices extends Controller {
    private static $full_page_rendering=false;

    public function index($setting=array()){
        if(!$this->config->get('module_probg_services_status'))return '';
        $this->load->language('extension/module/probg_services');
        $this->load->model('extension/probg_services/service');
        $this->load->model('tool/image');
        $category_id=(int)($this->request->get['probg_service_category_id']??0);
        $service_id=(int)($this->request->get['probg_service_id']??0);
        $route=(string)($this->request->get['route']??'');
        $is_request=$route==='extension/module/probg_services'||$category_id||$service_id;
        if(!$is_request||self::$full_page_rendering)return $this->module($setting);
        self::$full_page_rendering=true;
        $output=$service_id?$this->service($service_id,$category_id):($category_id?$this->category($category_id):$this->listing());
        self::$full_page_rendering=false;
        return $output;
    }

    private function listing(){
        $page=max(1,(int)($this->request->get['page']??1));
        $limit=max(1,(int)($this->config->get('module_probg_services_limit')?:12));
        $title=$this->language->get('heading_title');
        $this->document->setTitle($title);
        $canonical=$this->url->link('extension/module/probg_services',$page>1?'page='.$page:'',true);
        $this->document->addLink($canonical,'canonical');
        $this->social($title,'',$canonical,'CollectionPage','');
        $data=$this->layoutData();
        $data['heading_title']=$title;
        $data['breadcrumbs']=$this->breadcrumbs();
        $data['categories']=array();
        foreach($this->model_extension_probg_services_service->getCategories() as $c)$data['categories'][]=array('name'=>$c['name'],'subtitle'=>$c['subtitle'],'description'=>html_entity_decode($c['description_short'],ENT_QUOTES,'UTF-8'),'count'=>(int)$c['service_count'],'href'=>$this->url->link('extension/module/probg_services','probg_service_category_id='.(int)$c['category_id'],true));
        $total=$this->model_extension_probg_services_service->getTotalServices();
        $data['services']=$this->cards($this->model_extension_probg_services_service->getServices(array('start'=>($page-1)*$limit,'limit'=>$limit)));
        $this->pagination($data,$total,$page,$limit,'');
        return $this->render('probg_services_list',$data);
    }

    private function category($id){
        $category=$this->model_extension_probg_services_service->getCategory($id);
        if(!$category)return $this->notFound();
        $page=max(1,(int)($this->request->get['page']??1));
        $limit=max(1,(int)($this->config->get('module_probg_services_limit')?:12));
        $this->meta($category,$category['name']);
        $canonical=$this->url->link('extension/module/probg_services','probg_service_category_id='.$id.($page>1?'&page='.$page:''),true);
        $this->document->addLink($canonical,'canonical');
        $this->social($category['name'],$category['meta_description'],$canonical,'CollectionPage',$this->image($category['image'],1200,630));
        $data=$this->layoutData();
        $data['heading_title']=$category['name'];
        $data['subtitle']=$category['subtitle'];
        $data['description']=html_entity_decode($category['description'],ENT_QUOTES,'UTF-8');
        $data['breadcrumbs']=$this->breadcrumbs(array(array('text'=>$category['name'],'href'=>$canonical)));
        $total=$this->model_extension_probg_services_service->getTotalServices($id);
        $data['services']=$this->cards($this->model_extension_probg_services_service->getServices(array('category_id'=>$id,'start'=>($page-1)*$limit,'limit'=>$limit)));
        $this->pagination($data,$total,$page,$limit,'probg_service_category_id='.$id);
        return $this->render('probg_services_category',$data);
    }

    private function service($id,$requested_category=0){
        $service=$this->model_extension_probg_services_service->getService($id);
        if(!$service)return $this->notFound();
        $canonical=$this->url->link('extension/module/probg_services','probg_service_category_id='.(int)$service['category_id'].'&probg_service_id='.$id,true);
        if($requested_category&&$requested_category!=(int)$service['category_id']){$this->response->redirect($canonical,301);return '';}
        $this->meta($service,$service['name']);
        $this->document->addLink($canonical,'canonical');
        $share=$service['social_image']?:$service['image'];
        $this->social($service['name'],$service['meta_description'],$canonical,'Service',$this->image($share,1200,630),$service);

        $data=$this->layoutData();
        $data['service_id']=$id;
        $data['heading_title']=$service['name'];
        $data['subtitle']=$service['subtitle'];
        $data['short_description']=html_entity_decode($service['description_short'],ENT_QUOTES,'UTF-8');
        $data['description']=html_entity_decode($service['description'],ENT_QUOTES,'UTF-8');
        $data['image']=$this->image($service['image'],900,600);
        $data['price']=$service['show_price']?$this->currency->format($service['price'],$this->session->data['currency']):false;
        $data['price_text']=$service['price_text'];
        $data['button_text']=$service['button_text']?:$this->language->get('button_enquiry');
        $data['enquiry_status']=(int)$service['enquiry_status'];
        $data['category']=array('name'=>$service['category_name'],'href'=>$this->url->link('extension/module/probg_services','probg_service_category_id='.(int)$service['category_id'],true));
        $data['breadcrumbs']=$this->breadcrumbs(array(array('text'=>$service['category_name'],'href'=>$data['category']['href']),array('text'=>$service['name'],'href'=>$canonical)));
        $data['images']=array();
        foreach($this->model_extension_probg_services_service->getServiceImages($id) as $img)if($img['image']&&is_file(DIR_IMAGE.$img['image']))$data['images'][]=array('thumb'=>$this->model_tool_image->resize($img['image'],300,220),'popup'=>HTTP_SERVER.'image/'.$img['image']);
        $related=array();
        foreach($this->model_extension_probg_services_service->getRelatedServices($id) as $related_id){$r=$this->model_extension_probg_services_service->getService($related_id);if($r)$related[]=$r;}
        $data['related']=$this->cards($related);

        $data['enquiry_action']=$this->url->link('extension/probg_services/enquiry/submit','',true);
        $data['enquiry_success']=$this->session->data['probg_services_enquiry_success']??'';
        $data['enquiry_errors']=$this->session->data['probg_services_enquiry_errors']??array();
        $posted=$this->session->data['probg_services_enquiry_data']??array();
        unset($this->session->data['probg_services_enquiry_success'],$this->session->data['probg_services_enquiry_errors'],$this->session->data['probg_services_enquiry_data']);
        $data['enquiry_data']=array(
            'name'=>$posted['name']??($this->customer->isLogged()?$this->customer->getFirstName().' '.$this->customer->getLastName():''),
            'email'=>$posted['email']??($this->customer->isLogged()?$this->customer->getEmail():''),
            'telephone'=>$posted['telephone']??($this->customer->isLogged()?$this->customer->getTelephone():''),
            'company'=>$posted['company']??'',
            'website'=>$posted['website']??'',
            'subject'=>$posted['subject']??'',
            'budget'=>$posted['budget']??'',
            'desired_deadline'=>$posted['desired_deadline']??'',
            'message'=>$posted['message']??'',
            'privacy'=>!empty($posted['privacy'])
        );
        $data['captcha']='';
        if($this->config->get('config_captcha')&&$this->config->get('captcha_'.$this->config->get('config_captcha').'_status'))$data['captcha']=$this->load->controller('extension/captcha/'.$this->config->get('config_captcha'));

        return $this->render('probg_services_service',$data);
    }

    private function module($setting){$limit=max(1,min(100,(int)($setting['limit']??4)));$data['heading_title']=!empty($setting['name'])?$setting['name']:$this->language->get('heading_title');$data['services_url']=$this->url->link('extension/module/probg_services','',true);$data['services']=$this->cards($this->model_extension_probg_services_service->getServices(array('limit'=>$limit)));return $this->load->view('extension/module/probg_services',$data);}
    private function cards($rows){$out=array();foreach($rows as $r)$out[]=array('service_id'=>$r['service_id'],'name'=>$r['name'],'subtitle'=>$r['subtitle'],'description'=>utf8_substr(trim(strip_tags(html_entity_decode($r['description_short'],ENT_QUOTES,'UTF-8'))),0,180),'image'=>$this->image($r['image'],480,320),'price'=>$r['show_price']?$this->currency->format($r['price'],$this->session->data['currency']):false,'price_text'=>$r['price_text'],'href'=>$this->url->link('extension/module/probg_services','probg_service_category_id='.(int)$r['category_id'].'&probg_service_id='.(int)$r['service_id'],true));return $out;}

    private function layoutData(){return array(
        'column_left'=>$this->load->controller('common/column_left'),
        'column_right'=>$this->load->controller('common/column_right'),
        'content_top'=>$this->load->controller('common/content_top'),
        'content_bottom'=>$this->load->controller('common/content_bottom'),
        'text_no_results'=>$this->language->get('text_no_results'),
        'text_read_more'=>$this->language->get('text_read_more'),
        'text_related'=>$this->language->get('text_related'),
        'text_price'=>$this->language->get('text_price'),
        'text_enquiry_title'=>$this->language->get('text_enquiry_title'),
        'entry_name'=>$this->language->get('entry_name'),
        'entry_email'=>$this->language->get('entry_email'),
        'entry_telephone'=>$this->language->get('entry_telephone'),
        'entry_company'=>$this->language->get('entry_company'),
        'entry_website'=>$this->language->get('entry_website'),
        'entry_subject'=>$this->language->get('entry_subject'),
        'entry_budget'=>$this->language->get('entry_budget'),
        'entry_desired_deadline'=>$this->language->get('entry_desired_deadline'),
        'entry_message'=>$this->language->get('entry_message'),
        'entry_attachments'=>$this->language->get('entry_attachments'),
        'entry_privacy'=>$this->language->get('entry_privacy'),
        'help_attachments'=>$this->language->get('help_attachments'),
        'button_submit_enquiry'=>$this->language->get('button_submit_enquiry')
    );}
    private function breadcrumbs($extra=array()){return array_merge(array(array('text'=>$this->language->get('text_home'),'href'=>$this->url->link('common/home','',true)),array('text'=>$this->language->get('heading_title'),'href'=>$this->url->link('extension/module/probg_services','',true))),$extra);}
    private function pagination(&$data,$total,$page,$limit,$query){$p=new Pagination();$p->total=$total;$p->page=$page;$p->limit=$limit;$p->url=$this->url->link('extension/module/probg_services',($query?$query.'&':'').'page={page}',true);$data['pagination']=$p->render();$data['results']=sprintf($this->language->get('text_pagination'),$total?(($page-1)*$limit)+1:0,min($total,$page*$limit),$total,ceil($total/$limit));}
    private function meta($row,$fallback){$this->document->setTitle(!empty($row['meta_title'])?$row['meta_title']:$fallback);if(!empty($row['meta_description']))$this->document->setDescription($row['meta_description']);if(!empty($row['meta_keyword']))$this->document->setKeywords($row['meta_keyword']);}
    private function image($path,$w,$h){return $path&&is_file(DIR_IMAGE.$path)?$this->model_tool_image->resize($path,$w,$h):'';}
    private function social($title,$description,$url,$schema_type,$image='',$service=array()){
        $site=$this->config->get('config_name');$meta='<meta property="og:type" content="website" />\n<meta property="og:title" content="'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').'" />\n<meta property="og:description" content="'.htmlspecialchars(strip_tags($description),ENT_QUOTES,'UTF-8').'" />\n<meta property="og:url" content="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'" />\n<meta property="og:site_name" content="'.htmlspecialchars($site,ENT_QUOTES,'UTF-8').'" />\n';if($image)$meta.='<meta property="og:image" content="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'" />\n';$meta.='<meta name="twitter:card" content="'.($image?'summary_large_image':'summary').'" />\n<meta name="twitter:title" content="'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').'" />\n<meta name="twitter:description" content="'.htmlspecialchars(strip_tags($description),ENT_QUOTES,'UTF-8').'" />\n';if($image)$meta.='<meta name="twitter:image" content="'.htmlspecialchars($image,ENT_QUOTES,'UTF-8').'" />\n';$json=array('@context'=>'https://schema.org','@type'=>$schema_type,'name'=>$title,'url'=>$url);if($description)$json['description']=strip_tags($description);if($image)$json['image']=$image;if($schema_type==='Service'){$json['provider']=array('@type'=>'Organization','name'=>$site,'url'=>$this->url->link('common/home','',true));if(!empty($service['show_price']))$json['offers']=array('@type'=>'Offer','price'=>(string)$service['price'],'priceCurrency'=>$this->session->data['currency'],'url'=>$url);}$meta.='<script type="application/ld+json">'.json_encode($json,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>';$this->config->set('probg_services_social_meta',$meta);
    }
    private function render($view,$data){$data['header']=$this->load->controller('common/header');$data['footer']=$this->load->controller('common/footer');$this->response->setOutput($this->load->view('extension/module/'.$view,$data));return '';}
    private function notFound(){$this->response->addHeader($this->request->server['SERVER_PROTOCOL'].' 404 Not Found');$this->document->setTitle($this->language->get('text_not_found'));$data=$this->layoutData();$data['heading_title']=$this->language->get('text_not_found');$data['breadcrumbs']=$this->breadcrumbs();return $this->render('probg_services_not_found',$data);}
}
